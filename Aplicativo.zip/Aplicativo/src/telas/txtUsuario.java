/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package telas;

/**
 *
 * @author 2° ano
 */
class txtUsuario {
    
}
